balance = 1000

def check_balance():
    print(f"Your balance is: ${balance}")


# Function to deposit money
def deposit_money():
    global balance
    amount = float(input("Enter amount to deposit: $"))
    balance += amount
    print(f"Deposited: ${amount}. New balance: ${balance}")

def withdraw_money():
    global balance
    amount = float(input("Enter amount to withdraw: $"))
    if amount <= balance:
        balance -= amount
        print(f"Withdrawn: ${amount}. New balance: ${balance}")
    else:
        print("Insufficient balance!")

def atm():
    while True:
        print("\n1. Check Balance\n2. Deposit Money\n3. Withdraw Money\n4. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            check_balance()
        elif choice == '2':
            deposit_money()
        elif choice == '3':
            withdraw_money()
        elif choice == '4':
            print("Thank you")
            break
        else:
            print("Invalid option. Please choose again.")

atm()